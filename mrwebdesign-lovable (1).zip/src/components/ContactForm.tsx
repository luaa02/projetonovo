import React, { useState } from 'react';
import { Send, CheckCircle2, MessageSquare, Shield, Clock, ArrowUpRight, Instagram } from 'lucide-react';
import { WHATSAPP_DISPLAY, createWhatsAppUrl, INSTAGRAM_URL, INSTAGRAM_HANDLE } from '../data/portfolioData';
import { ContactFormData } from '../types';

export const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    whatsapp: '',
    company: '',
    projectType: '',
    investmentTier: 'Site Essencial — R$ 600,00',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!formData.name.trim()) errs.name = 'Por favor, informe seu nome completo.';
    if (!formData.whatsapp.trim() || formData.whatsapp.length < 8) {
      errs.whatsapp = 'Informe um número de WhatsApp válido com DDD.';
    }
    if (!formData.company.trim()) errs.company = 'Informe o nome da sua empresa ou profissão.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // Generate formatted WhatsApp message
    const formattedMessage = `*Novo Pedido de Orçamento - MR Web Design*\n\n` +
      `*Nome:* ${formData.name}\n` +
      `*WhatsApp:* ${formData.whatsapp}\n` +
      `*Empresa / Nicho:* ${formData.company}\n` +
      `*Plano Escolhido:* ${formData.investmentTier}\n` +
      `*Detalhes:* ${formData.message || 'Sem observações adicionais.'}\n\n` +
      `Gostaria de agendar uma consultoria e receber a proposta!`;

    const waUrl = createWhatsAppUrl(formattedMessage);
    
    // Open WhatsApp in new tab
    window.open(waUrl, '_blank', 'noopener,noreferrer');
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({
      name: '',
      whatsapp: '',
      company: '',
      projectType: '',
      investmentTier: 'Site Essencial — R$ 600,00',
      message: ''
    });
  };

  return (
    <section id="contato" className="py-20 md:py-32 bg-[#0E0E0E] relative border-t border-white/[0.06]">
      {/* Background glow */}
      <div 
        className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[600px] h-[500px] pointer-events-none opacity-20 blur-[140px] rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(212, 175, 55, 0.25) 0%, rgba(14, 14, 14, 0) 70%)'
        }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
            Inicie Seu Projeto Agora
          </p>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
            Solicite um Orçamento Sem Compromisso
          </h2>
          <div className="w-16 h-[2px] bg-[#D4AF37] mt-5 mb-4" />
          <p className="text-base text-neutral-300">
            Preencha os dados abaixo para receber uma proposta personalizada ou fale diretamente com a Mariany no WhatsApp.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Direct Contacts & Guarantees */}
          <div className="lg:col-span-5 space-y-8">
            <div className="p-7 rounded-2xl bg-[#141414] border border-white/[0.08] space-y-6">
              <div>
                <h3 className="font-serif-luxury text-xl font-bold text-white mb-2">
                  Atendimento Exclusivo
                </h3>
                <p className="text-sm text-neutral-300 leading-relaxed">
                  Você não falará com robôs. Todos os orçamentos são analisados e respondidos pessoalmente por Mariany Rodrigues com foco na sua meta de faturamento.
                </p>
              </div>

              {/* Direct channels */}
              <div className="space-y-4 pt-2 border-t border-white/[0.06]">
                <a
                  href={createWhatsAppUrl("Olá, Mariany! Gostaria de tirar dúvidas rápidas sobre criação de sites no WhatsApp.")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-4 rounded-xl bg-[#1A1A1A] hover:bg-[#202020] border border-white/[0.08] hover:border-[#D4AF37]/50 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37]">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs text-neutral-400 block">WhatsApp Oficial</span>
                      <span className="text-sm font-semibold text-white group-hover:text-[#D4AF37] transition-colors">
                        {WHATSAPP_DISPLAY}
                      </span>
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-[#D4AF37] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>

                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-4 rounded-xl bg-[#1A1A1A] hover:bg-[#202020] border border-white/[0.08] hover:border-[#D4AF37]/50 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37]">
                      <Instagram className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs text-neutral-400 block">Instagram</span>
                      <span className="text-sm font-semibold text-white group-hover:text-[#D4AF37] transition-colors">
                        @{INSTAGRAM_HANDLE}
                      </span>
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-[#D4AF37] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>
              </div>
            </div>

            {/* Assurance badges */}
            <div className="space-y-4">
              <div className="flex items-start gap-3 text-xs text-neutral-300">
                <Clock className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span><strong>Resposta Rápida:</strong> Retorno em até 2 horas em dias úteis com direcionamento comercial.</span>
              </div>
              <div className="flex items-start gap-3 text-xs text-neutral-300">
                <Shield className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span><strong>Segurança & Sigilo:</strong> Suas informações e estratégias de negócio estão 100% protegidas.</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Form */}
          <div className="lg:col-span-7">
            <div className="p-7 sm:p-9 rounded-2xl bg-[#121212] border border-white/[0.12] shadow-2xl relative">
              
              {submitted ? (
                <div className="text-center py-12 space-y-6 animate-fadeIn">
                  <div className="w-16 h-16 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37] mx-auto flex items-center justify-center text-[#D4AF37]">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-serif-luxury text-2xl font-bold text-white">
                      Solicitação Enviada com Sucesso!
                    </h3>
                    <p className="text-sm text-neutral-300 max-w-md mx-auto">
                      Seu pedido de orçamento foi estruturado e a conversa no WhatsApp foi iniciada. Caso a janela não tenha aberto automaticamente, clique no botão abaixo:
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
                    <a
                      href={createWhatsAppUrl(`Olá, Mariany! Acabei de preencher o formulário para ${formData.name} (${formData.company}). Gostaria de dar continuidade!`)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all"
                    >
                      <span>Abrir Conversa no WhatsApp</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </a>
                    <button
                      onClick={handleReset}
                      className="w-full sm:w-auto px-5 py-3 text-xs text-neutral-400 hover:text-white transition-colors"
                    >
                      Enviar outra solicitação
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Name */}
                    <div>
                      <label htmlFor="contact-name" className="block text-xs font-medium text-neutral-300 mb-1.5">
                        Seu Nome *
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ex: João Silva"
                        className={`w-full px-4 py-3 rounded-lg bg-[#181818] border text-white text-sm placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                          errors.name ? 'border-red-500' : 'border-white/[0.08]'
                        }`}
                      />
                      {errors.name && <p className="text-[11px] text-red-400 mt-1">{errors.name}</p>}
                    </div>

                    {/* WhatsApp */}
                    <div>
                      <label htmlFor="contact-whatsapp" className="block text-xs font-medium text-neutral-300 mb-1.5">
                        Seu WhatsApp com DDD *
                      </label>
                      <input
                        id="contact-whatsapp"
                        type="tel"
                        value={formData.whatsapp}
                        onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                        placeholder="Ex: (11) 99999-9999"
                        className={`w-full px-4 py-3 rounded-lg bg-[#181818] border text-white text-sm placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                          errors.whatsapp ? 'border-red-500' : 'border-white/[0.08]'
                        }`}
                      />
                      {errors.whatsapp && <p className="text-[11px] text-red-400 mt-1">{errors.whatsapp}</p>}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Company / Nicho */}
                    <div>
                      <label htmlFor="contact-company" className="block text-xs font-medium text-neutral-300 mb-1.5">
                        Sua Empresa / Nicho *
                      </label>
                      <input
                        id="contact-company"
                        type="text"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                        placeholder="Ex: Clínica Alpha / E-commerce de Calçados"
                        className={`w-full px-4 py-3 rounded-lg bg-[#181818] border text-white text-sm placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                          errors.company ? 'border-red-500' : 'border-white/[0.08]'
                        }`}
                      />
                      {errors.company && <p className="text-[11px] text-red-400 mt-1">{errors.company}</p>}
                    </div>

                    {/* Plano Escolhido */}
                    <div>
                      <label htmlFor="contact-investment" className="block text-xs font-medium text-neutral-300 mb-1.5">
                        Plano Escolhido
                      </label>
                      <select
                        id="contact-investment"
                        value={formData.investmentTier}
                        onChange={(e) => setFormData({ ...formData, investmentTier: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg bg-[#181818] border border-white/[0.08] text-white text-sm focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
                      >
                        <option value="Site Simples — R$ 300,00 (Presença Online Profissional)">Site Simples — R$ 300,00</option>
                        <option value="Site Essencial — R$ 600,00 (Mais Páginas e Funcionalidades)">Site Essencial — R$ 600,00</option>
                        <option value="Site Premium — R$ 1.000,00 (Experiência Digital Completa)">Site Premium — R$ 1.000,00</option>
                        <option value="Desejo consultoria prévia no WhatsApp">Desejo consultoria prévia no WhatsApp</option>
                      </select>
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label htmlFor="contact-message" className="block text-xs font-medium text-neutral-300 mb-1.5">
                      Conte um pouco sobre suas metas e o que busca (Opcional)
                    </label>
                    <textarea
                      id="contact-message"
                      rows={3}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Ex: Gostaria de aumentar o volume de clientes que chegam pelo tráfego pago e modernizar a identidade..."
                      className="w-full px-4 py-3 rounded-lg bg-[#181818] border border-white/[0.08] text-white text-sm placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-4 px-6 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all duration-300 shadow-[0_0_25px_rgba(212,175,55,0.25)] hover:shadow-[0_0_35px_rgba(212,175,55,0.45)] active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>Solicitar Orçamento no WhatsApp Agora</span>
                      <Send className="w-4 h-4" />
                    </button>
                    <p className="text-[11px] text-neutral-400 text-center mt-2">
                      Ao clicar, você será direcionado para o WhatsApp com todos os detalhes já preenchidos.
                    </p>
                  </div>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
