export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  shortDesc: string;
  features: string[];
  idealFor: string;
  impactMetric: string;
}

export interface PortfolioProject {
  id: string;
  title: string;
  category: string;
  client: string;
  year: string;
  impact: string;
  description: string;
  deliverables: string[];
  imageUrl: string;
  aspectRatio: string;
  accentText: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  quote: string;
  metric: string;
}

export interface PricingPlan {
  id: string;
  tier: string;
  name: string;
  price: string;
  tagline: string;
  popular?: boolean;
  features: string[];
  idealFor: string;
}

export interface ContactFormData {
  name: string;
  whatsapp: string;
  company: string;
  projectType?: string;
  investmentTier: string;
  message: string;
}
