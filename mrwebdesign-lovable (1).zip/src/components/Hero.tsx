import React from 'react';
import { ArrowUpRight, ShieldCheck, Zap, TrendingUp, Sparkles } from 'lucide-react';
import { createWhatsAppUrl } from '../data/portfolioData';

export const Hero: React.FC = () => {
  return (
    <section id="inicio" className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden bg-[#0A0A0A]">
      {/* Subtle radial gold aura backdrop */}
      <div 
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] pointer-events-none opacity-25 blur-[120px] rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(212, 175, 55, 0.3) 0%, rgba(10, 10, 10, 0) 70%)'
        }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Split Grid Desktop */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Typographic Hierarchy & Conversion Engine */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-6">
            
            {/* Subtle editorial kicker without pill enclosure */}
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#D4AF37] uppercase">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>MR Web Design · Estúdio Criativo & Estratégico</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.12]">
              O futuro da sua marca <br className="hidden sm:inline" />
              <span className="gold-gradient-text">começa aqui.</span>
            </h1>

            {/* Concrete Value Proposition for revenue growth */}
            <p className="text-base sm:text-lg text-neutral-300 max-w-2xl leading-relaxed">
              Criamos sites modernos, responsivos e de alto padrão sob medida para 
              <strong className="text-white font-semibold"> empresas que querem aumentar seu faturamento</strong>.
              Unimos design refinado, carregamento ultra rápido e arquitetura persuasiva que converte visitantes em clientes fiéis.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2 w-full sm:w-auto">
              <a
                href={createWhatsAppUrl("Olá, Mariany! Gostaria de falar sobre o projeto do meu novo site e solicitar um orçamento no WhatsApp.")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 text-xs sm:text-sm font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all duration-300 shadow-[0_0_25px_rgba(212,175,55,0.25)] hover:shadow-[0_0_35px_rgba(212,175,55,0.45)] active:scale-95 text-center"
              >
                <span>Solicitar Orçamento no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 shrink-0" />
              </a>

              <a
                href="#portfolio"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-xs sm:text-sm font-medium tracking-wide text-neutral-300 hover:text-white bg-[#141414] hover:bg-[#1A1A1A] border border-white/[0.08] hover:border-[#D4AF37]/50 rounded-lg transition-all duration-300 text-center"
              >
                <span>Conhecer Projetos</span>
              </a>
            </div>

            {/* Trust highlights text line */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-neutral-400 pt-3">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                Atendimento exclusivo direto com a criadora
              </span>
              <span className="hidden sm:inline text-neutral-600" aria-hidden="true">·</span>
              <span className="flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-[#D4AF37]" />
                Alta velocidade & mobile first
              </span>
              <span className="hidden sm:inline text-neutral-600" aria-hidden="true">·</span>
              <span className="flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-[#D4AF37]" />
                Foco em conversão e lucro
              </span>
            </div>

          </div>

          {/* Right Column: Visual Hero Asset */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-white/[0.12] bg-[#121212] shadow-2xl group transition-all duration-500 hover:border-[#D4AF37]/50">
              
              {/* Image Container with Fallback */}
              <div className="relative aspect-[16/10] sm:aspect-[4/3] lg:aspect-[16/11] overflow-hidden bg-neutral-900">
                <img
                  src="/images/hero_showcase.jpg"
                  alt="Apresentação de sites modernos em múltiplos dispositivos criada pela MR Web Design"
                  className="w-full h-full object-cover object-center transform transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                  loading="eager"
                />
                
                {/* Visual Glass Overlay Gradient */}
                <div 
                  className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/30 to-transparent pointer-events-none"
                  aria-hidden="true" 
                />

                {/* Floating Micro Card */}
                <div className="absolute bottom-4 left-4 right-4 bg-[#0E0E0E]/90 backdrop-blur-md border border-[#D4AF37]/30 rounded-xl p-3.5 shadow-xl flex items-center justify-between gap-3">
                  <div>
                    <p className="text-[11px] uppercase tracking-wider text-[#D4AF37] font-semibold">
                      Padrão de Excelência
                    </p>
                    <p className="text-xs text-white font-medium">
                      Interfaces que transmitem credibilidade e geram vendas
                    </p>
                  </div>
                  <span className="text-xs text-neutral-400 font-mono tabular-nums whitespace-nowrap shrink-0">
                    100% Personalizado
                  </span>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Full-width Metric & Trust Strip below Hero Split */}
        <div className="mt-16 sm:mt-24 pt-8 border-t border-white/[0.08] grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
          <div className="space-y-1">
            <p className="font-serif-luxury text-2xl sm:text-3xl font-bold text-white tracking-tight tabular-nums">
              +185%
            </p>
            <p className="text-xs text-neutral-400 leading-snug">
              Média de aumento em conversão de visitantes para contatos qualificados.
            </p>
          </div>

          <div className="space-y-1">
            <p className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#D4AF37] tracking-tight tabular-nums">
              &lt; 1.5s
            </p>
            <p className="text-xs text-neutral-400 leading-snug">
              Carregamento ultra veloz para não perder nenhum cliente por lentidão.
            </p>
          </div>

          <div className="space-y-1">
            <p className="font-serif-luxury text-2xl sm:text-3xl font-bold text-white tracking-tight tabular-nums">
              100%
            </p>
            <p className="text-xs text-neutral-400 leading-snug">
              Responsivo em qualquer smartphone, tablet ou computador.
            </p>
          </div>

          <div className="space-y-1">
            <p className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#D4AF37] tracking-tight">
              VIP
            </p>
            <p className="text-xs text-neutral-400 leading-snug">
              Atendimento direto e personalizado para a realidade do seu negócio.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
