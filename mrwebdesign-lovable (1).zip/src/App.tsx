import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Pricing } from './components/Pricing';
import { Portfolio } from './components/Portfolio';
import { Testimonials } from './components/Testimonials';
import { ContactForm } from './components/ContactForm';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { AdminPhotoModal } from './components/AdminPhotoModal';
import { FOUNDER_INFO } from './data/portfolioData';

export default function App() {
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [marianyPhoto, setMarianyPhoto] = useState<string>(FOUNDER_INFO.image);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('admin') === 'true') {
      setIsAdminOpen(true);
    }
  }, []);

  const handlePhotoSelected = (dataUrl: string) => {
    setMarianyPhoto(dataUrl);
    localStorage.setItem('mr_mariany_official_photo', dataUrl);
  };

  const handleResetToDefault = () => {
    localStorage.removeItem('mr_mariany_official_photo');
    setMarianyPhoto(FOUNDER_INFO.image);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-neutral-100 flex flex-col font-sans selection:bg-[#D4AF37]/20 selection:text-[#E5C365]">
      {/* 1. Header Navigation conforming to Top Bar Contract */}
      <Navbar />

      <main className="flex-grow">
        {/* 1. Seção inicial impactante */}
        <Hero />

        {/* 2. Sobre / Quem sou */}
        <About 
          customPhoto={marianyPhoto} 
          onOpenAdmin={() => setIsAdminOpen(true)} 
        />

        {/* 3. Serviços */}
        <Services />

        {/* Tabela de Preços & Planos Oficiais */}
        <Pricing />

        {/* 4. Portfólio / Projetos */}
        <Portfolio />

        {/* 5. Depoimentos */}
        <Testimonials />

        {/* 6. Formulário de contato */}
        <ContactForm />
      </main>

      {/* 7. WhatsApp flutuante */}
      <FloatingWhatsApp />

      {/* Rodapé institucional com link discreto para Mariany */}
      <Footer onOpenAdmin={() => setIsAdminOpen(true)} />

      {/* Modal Privado de Upload da Foto da Mariany */}
      <AdminPhotoModal 
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        currentPhoto={marianyPhoto}
        onPhotoSelected={handlePhotoSelected}
        onResetToDefault={handleResetToDefault}
      />
    </div>
  );
}
