import React, { useState } from 'react';
import { ArrowUpRight, Check, Sparkles } from 'lucide-react';
import { SERVICES_DATA, createWhatsAppUrl } from '../data/portfolioData';

export const Services: React.FC = () => {
  const [selectedService, setSelectedService] = useState<string>(SERVICES_DATA[0].id);

  return (
    <section id="servicos" className="py-20 md:py-32 bg-[#0A0A0A] relative border-t border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
              Soluções Digitais Estratégicas
            </p>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
              Criação de Sites no Geral
            </h2>
            <div className="w-16 h-[2px] bg-[#D4AF37] mt-5 mb-4" />
            <p className="text-base text-neutral-300">
              Desenvolvemos desde landing pages objetivas de conversão imediata até ecossistemas corporativos e e-commerce de alto volume.
            </p>
          </div>

          <div className="shrink-0">
            <a
              href={createWhatsAppUrl("Olá! Quero um diagnóstico gratuito para entender qual tipo de site trará mais retorno para o meu negócio.")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#D4AF37] hover:text-[#E5C365] transition-colors group"
            >
              <span>Solicitar Diagnóstico Gratuito</span>
              <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>
        </div>

        {/* Services Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES_DATA.map((service, index) => {
            const isMarquee = index === 0 || index === 1; // marquee cards
            return (
              <div
                key={service.id}
                onClick={() => setSelectedService(service.id)}
                className={`group cursor-pointer rounded-2xl p-7 transition-all duration-300 flex flex-col justify-between ${
                  isMarquee && index === 0
                    ? 'md:col-span-2 lg:col-span-2 bg-gradient-to-br from-[#161616] to-[#0E0E0E] border border-[#D4AF37]/35 shadow-[0_10px_30px_rgba(0,0,0,0.6)]'
                    : 'bg-[#121212] border border-white/[0.08] hover:border-[#D4AF37]/40 hover:bg-[#161616]'
                } ${selectedService === service.id ? 'ring-1 ring-[#D4AF37]/60' : ''}`}
              >
                <div>
                  {/* Card Editorial Number & Indicator */}
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-serif-luxury text-xl font-bold text-[#D4AF37] tabular-nums">
                      {service.number}.
                    </span>
                    <span className="text-[11px] text-neutral-400 font-medium uppercase tracking-wider">
                      {service.impactMetric}
                    </span>
                  </div>

                  {/* Title & Short description */}
                  <h3 className="font-serif-luxury text-xl sm:text-2xl font-bold text-white group-hover:text-[#D4AF37] transition-colors mb-3">
                    {service.title}
                  </h3>
                  <p className="text-sm text-neutral-300 leading-relaxed mb-6">
                    {service.shortDesc}
                  </p>

                  {/* Features List */}
                  <div className="space-y-2.5 pt-2 border-t border-white/[0.06] mb-6">
                    {service.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-start gap-2.5 text-xs text-neutral-300">
                        <Check className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer of Card with Ideal Audience & Action */}
                <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between gap-3">
                  <div className="text-[11px] text-neutral-400">
                    <span className="text-neutral-500">Indicado para:</span> {service.idealFor}
                  </div>
                  
                  <a
                    href={createWhatsAppUrl(`Olá, Mariany! Gostaria de um orçamento para o serviço de ${service.title}.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="p-2.5 rounded-lg bg-[#1A1A1A] group-hover:bg-[#D4AF37] text-[#D4AF37] group-hover:text-black transition-all duration-300 shrink-0"
                    title={`Solicitar orçamento para ${service.title}`}
                    aria-label={`Solicitar orçamento para ${service.title}`}
                  >
                    <ArrowUpRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Revenue Callout Banner */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#141414] via-[#181818] to-[#141414] border border-[#D4AF37]/30 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif-luxury text-base sm:text-lg font-bold text-white">
                Não tem certeza de qual formato é ideal para a sua empresa?
              </h4>
              <p className="text-xs sm:text-sm text-neutral-300">
                Avaliamos o modelo de negócio da sua marca e sugerimos a estrutura com o menor custo e maior retorno em vendas.
              </p>
            </div>
          </div>

          <a
            href={createWhatsAppUrl("Olá, Mariany! Gostaria de uma consultoria rápida para saber qual tipo de site é melhor para alavancar minhas vendas.")}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full md:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all duration-300 whitespace-nowrap shrink-0"
          >
            <span>Consultar Mariany no WhatsApp</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
};
