import React from 'react';
import { Quote, ArrowUpRight, TrendingUp } from 'lucide-react';
import { TESTIMONIALS_DATA, createWhatsAppUrl } from '../data/portfolioData';

export const Testimonials: React.FC = () => {
  return (
    <section id="depoimentos" className="py-20 md:py-32 bg-[#0A0A0A] relative border-t border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
            Histórias de Sucesso & Resultados Comerciais
          </p>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
            O Que Nossos Clientes Dizem
          </h2>
          <div className="w-16 h-[2px] bg-[#D4AF37] mt-5 mb-4" />
          <p className="text-base text-neutral-300">
            A satisfação de quem confiou na MR Web Design para transformar sua presença digital em uma máquina de vendas.
          </p>
        </div>

        {/* Testimonials Grid (2x2 on desktop, clean spacing) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {TESTIMONIALS_DATA.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl bg-[#121212] border border-white/[0.08] hover:border-[#D4AF37]/40 p-7 sm:p-8 flex flex-col justify-between transition-all duration-300 group hover:bg-[#161616]"
            >
              <div>
                {/* Header of Quote card */}
                <div className="flex items-center justify-between mb-6">
                  <Quote className="w-7 h-7 text-[#D4AF37]/60 group-hover:text-[#D4AF37] transition-colors" />
                  
                  {/* Quantified impact banner */}
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#D4AF37] bg-[#1C1C1C] px-3 py-1.5 rounded-lg border border-[#D4AF37]/20">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>{item.metric}</span>
                  </div>
                </div>

                {/* Quote Body */}
                <p className="text-sm sm:text-base text-neutral-200 leading-relaxed italic mb-8">
                  &ldquo;{item.quote}&rdquo;
                </p>
              </div>

              {/* Author Info */}
              <div className="pt-5 border-t border-white/[0.06] flex items-center justify-between">
                <div>
                  <h4 className="font-serif-luxury text-base font-bold text-white group-hover:text-[#D4AF37] transition-colors">
                    {item.name}
                  </h4>
                  <p className="text-xs text-neutral-400">
                    {item.role} · <span className="text-neutral-300">{item.company}</span>
                  </p>
                </div>

                <span className="text-[11px] text-[#D4AF37] font-mono tracking-wider">
                  Verificado
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Social Proof Bar */}
        <div className="mt-16 p-6 rounded-2xl bg-[#141414] border border-white/[0.06] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs sm:text-sm text-neutral-300 text-center sm:text-left">
            Pronto para colocar o seu negócio no mesmo patamar de faturamento?
          </div>
          <a
            href={createWhatsAppUrl("Olá, Mariany! Gostaria de agendar uma conversa sobre o site da minha empresa.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] px-6 py-3 rounded-lg transition-all duration-300 whitespace-nowrap"
          >
            <span>Falar com Mariany no WhatsApp</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>

      </div>
    </section>
  );
};
