import React, { useState, useEffect } from 'react';
import { MessageCircle, X, ArrowUpRight } from 'lucide-react';
import { createWhatsAppUrl, WHATSAPP_DISPLAY } from '../data/portfolioData';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);

  useEffect(() => {
    // Show subtle greeting after 4 seconds if not interacted
    const timer = setTimeout(() => {
      if (!hasInteracted) {
        setShowTooltip(true);
      }
    }, 4000);
    return () => clearTimeout(timer);
  }, [hasInteracted]);

  const handleCloseTooltip = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowTooltip(false);
    setHasInteracted(true);
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Floating Greeting Bubble */}
      {showTooltip && (
        <div className="mb-3 max-w-xs bg-[#161616] border border-[#D4AF37]/40 rounded-2xl p-4 shadow-2xl relative animate-fadeIn">
          <button
            onClick={handleCloseTooltip}
            className="absolute top-2 right-2 text-neutral-400 hover:text-white p-1 rounded-md"
            aria-label="Fechar mensagem rápida"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          
          <div className="flex items-center gap-2.5 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37]" aria-hidden="true" />
            <span className="text-xs font-semibold text-white">Mariany Rodrigues · MR Web Design</span>
          </div>
          
          <p className="text-xs text-neutral-300 mb-3 leading-relaxed">
            Olá! Precisa de um site moderno que gere mais vendas para a sua empresa? Estou online no WhatsApp para tirar dúvidas.
          </p>

          <a
            href={createWhatsAppUrl("Olá, Mariany! Gostaria de conversar agora no WhatsApp sobre um site para minha empresa.")}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setHasInteracted(true)}
            className="inline-flex items-center justify-center gap-1.5 w-full py-2 px-3 text-[11px] font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all"
          >
            <span>Iniciar Conversa</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>
      )}

      {/* Main Floating Circle Button */}
      <a
        href={createWhatsAppUrl("Olá, Mariany! Gostaria de solicitar um orçamento no WhatsApp com a MR Web Design.")}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={`Conversar no WhatsApp com MR Web Design no número ${WHATSAPP_DISPLAY}`}
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-[#D4AF37] hover:bg-[#E5C365] text-black shadow-[0_8px_30px_rgba(212,175,55,0.4)] hover:shadow-[0_8px_35px_rgba(212,175,55,0.6)] transition-all duration-300 active:scale-95"
      >
        <MessageCircle className="w-7 h-7 text-black transition-transform group-hover:scale-110" />
        
        {/* Subtle hover pulse */}
        <span 
          className="absolute -inset-1 rounded-full border border-[#D4AF37]/50 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" 
          aria-hidden="true" 
        />
      </a>
    </div>
  );
};
