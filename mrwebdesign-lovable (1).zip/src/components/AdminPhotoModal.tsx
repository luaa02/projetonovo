import React, { useRef } from 'react';
import { X, Upload, CheckCircle2, Shield, Info, Download } from 'lucide-react';

interface AdminPhotoModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPhoto: string;
  onPhotoSelected: (dataUrl: string) => void;
  onResetToDefault: () => void;
}

export const AdminPhotoModal: React.FC<AdminPhotoModalProps> = ({
  isOpen,
  onClose,
  currentPhoto,
  onPhotoSelected,
  onResetToDefault
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        onPhotoSelected(result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-lg bg-[#141414] border border-[#D4AF37]/50 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-serif-luxury text-lg font-bold text-white">
              Painel Privado da Criadora (Mariany)
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white bg-[#1E1E1E]"
            aria-label="Fechar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Info */}
        <div className="p-3.5 rounded-xl bg-[#1A1A1A] border border-white/[0.06] text-xs text-neutral-300 space-y-2">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
            <p>
              <strong>Visitantes não têm acesso a esta tela.</strong> Aqui você define a sua foto original 100% real (sem qualquer filtro ou inteligência artificial).
            </p>
          </div>
        </div>

        {/* Dropzone */}
        <div 
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className="p-8 border-2 border-dashed border-[#D4AF37]/40 hover:border-[#D4AF37] rounded-xl bg-[#0D0D0D] cursor-pointer text-center space-y-3 transition-colors group"
        >
          <input 
            type="file" 
            ref={fileInputRef} 
            accept="image/*" 
            onChange={handleFileChange} 
            className="hidden" 
          />
          <div className="w-12 h-12 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#D4AF37] flex items-center justify-center mx-auto group-hover:scale-105 transition-transform">
            <Upload className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm font-semibold text-white">
              Clique ou arraste seu arquivo original aqui
            </p>
            <p className="text-xs text-neutral-400 mt-1">
              (Selecione seu arquivo Retrato... ou WhatsApp Image...)
            </p>
          </div>
        </div>

        {/* Preview & Actions */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-3">
            <img 
              src={currentPhoto} 
              alt="Prévia atual" 
              className="w-12 h-12 rounded-lg object-cover border border-white/[0.1]" 
            />
            <span className="text-xs text-neutral-400">Prévia Atual</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onResetToDefault}
              className="px-3 py-2 text-xs text-neutral-400 hover:text-white transition-colors"
            >
              Restaurar Padrão
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-colors"
            >
              Concluir
            </button>
          </div>
        </div>

        {/* Export / Download ZIP Section */}
        <div className="pt-4 border-t border-white/[0.08] space-y-2.5">
          <p className="text-xs font-semibold text-white uppercase tracking-wider flex items-center justify-between">
            <span>Baixar Arquivos ZIP do Projeto</span>
            <span className="text-[10px] text-[#D4AF37] font-mono lowercase">.zip pronto</span>
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <a
              href="/mrwebdesign-codigo-fonte.zip"
              download="mrwebdesign-codigo-fonte.zip"
              className="inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] border border-white/[0.1] text-xs text-white font-medium transition-colors hover:border-[#D4AF37]/50"
            >
              <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Código Fonte (Lovable/Git)</span>
            </a>
            <a
              href="/mrwebdesign-site-pronto-netlify.zip"
              download="mrwebdesign-site-pronto-netlify.zip"
              className="inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] border border-white/[0.1] text-xs text-white font-medium transition-colors hover:border-[#D4AF37]/50"
            >
              <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Site Pronto (Netlify Drop)</span>
            </a>
          </div>
        </div>

      </div>
    </div>
  );
};
