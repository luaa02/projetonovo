import React, { useState } from 'react';
import { ArrowUpRight, ExternalLink, Sparkles } from 'lucide-react';
import { PORTFOLIO_PROJECTS, createWhatsAppUrl } from '../data/portfolioData';
import { PortfolioProject } from '../types';
import { ProjectModal } from './ProjectModal';

export const Portfolio: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);

  const categories = [
    { id: 'all', label: 'Todos os Projetos' },
    { id: 'ecommerce', label: 'E-commerce & Lojas' },
    { id: 'clinica', label: 'Saúde & Estética' },
    { id: 'b2b', label: 'Corporativo & B2B' },
  ];

  const filteredProjects = PORTFOLIO_PROJECTS.filter((proj) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'ecommerce') return proj.category.toLowerCase().includes('commerce');
    if (activeCategory === 'clinica') return proj.category.toLowerCase().includes('saúde') || proj.category.toLowerCase().includes('estética');
    if (activeCategory === 'b2b') return proj.category.toLowerCase().includes('b2b') || proj.category.toLowerCase().includes('institucional');
    return true;
  });

  return (
    <section id="portfolio" className="py-20 md:py-32 bg-[#0E0E0E] relative border-t border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
              Casos Reais & Portfólio Selecionado
            </p>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
              Projetos Que Geram Faturamento
            </h2>
            <div className="w-16 h-[2px] bg-[#D4AF37] mt-5 mb-4" />
            <p className="text-base text-neutral-300">
              Cada site é arquitetado com um único objetivo: elevar a percepção de valor do negócio e transformar visitantes em clientes pagantes.
            </p>
          </div>

          {/* Interactive Category Tabs */}
          <div className="flex flex-wrap items-center gap-2 p-1 bg-[#161616] border border-white/[0.08] rounded-xl shrink-0">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all duration-200 whitespace-nowrap shrink-0 ${
                  activeCategory === cat.id
                    ? 'bg-[#D4AF37] text-black font-semibold shadow-sm'
                    : 'text-neutral-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Project Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {filteredProjects.map((project, idx) => {
            // First project is wide featured (span-7), others span-5 or span-6
            const isFeatured = idx === 0;
            return (
              <div
                key={project.id}
                className={`group rounded-2xl bg-[#121212] border border-white/[0.08] hover:border-[#D4AF37]/50 overflow-hidden transition-all duration-500 flex flex-col justify-between ${
                  isFeatured ? 'lg:col-span-7' : 'lg:col-span-5'
                }`}
              >
                {/* Media Showcase container */}
                <div 
                  className="relative overflow-hidden cursor-pointer bg-neutral-950 aspect-[16/10]"
                  onClick={() => setSelectedProject(project)}
                >
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  
                  {/* Subtle Scrim gradient */}
                  <div 
                    className="absolute inset-0 bg-gradient-to-t from-[#121212] via-black/20 to-transparent pointer-events-none" 
                    aria-hidden="true" 
                  />

                  {/* Impact Tag overlay */}
                  <div className="absolute top-4 left-4 bg-[#0A0A0A]/85 backdrop-blur-md border border-[#D4AF37]/30 px-3 py-1.5 rounded-lg text-xs font-semibold text-[#D4AF37]">
                    {project.impact}
                  </div>

                  {/* Hover explore button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-xs">
                    <span className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#D4AF37] text-black font-semibold text-xs uppercase tracking-wider shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-transform">
                      <span>Ver Detalhes do Projeto</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>

                {/* Content Details */}
                <div className="p-6 sm:p-7 flex flex-col justify-between flex-grow">
                  <div>
                    {/* Unboxed metadata separator per rule 1.A */}
                    <div className="flex items-center gap-2 text-xs text-neutral-400 mb-2">
                      <span className="text-[#D4AF37] font-medium">{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.client}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.year}</span>
                    </div>

                    <h3 
                      onClick={() => setSelectedProject(project)}
                      className="font-serif-luxury text-xl sm:text-2xl font-bold text-white group-hover:text-[#D4AF37] transition-colors cursor-pointer mb-3"
                    >
                      {project.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-neutral-300 line-clamp-3 leading-relaxed mb-6">
                      {project.description}
                    </p>
                  </div>

                  {/* Footer actions */}
                  <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between">
                    <button
                      onClick={() => setSelectedProject(project)}
                      className="text-xs font-semibold uppercase tracking-wider text-[#D4AF37] hover:text-[#E5C365] transition-colors inline-flex items-center gap-1.5"
                    >
                      <span>Estudo de Caso Completo</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>

                    <a
                      href={createWhatsAppUrl(`Olá, Mariany! Vi o case do ${project.title} no portfólio e gostaria de um site semelhante para minha empresa.`)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-neutral-400 hover:text-white transition-colors"
                      title="Solicitar projeto similar"
                    >
                      Pedir similar &rarr;
                    </a>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Global CTA Strip */}
        <div className="mt-16 text-center">
          <p className="text-sm text-neutral-400 mb-4">
            Cada negócio possui uma identidade exclusiva. Vamos desenhar a sua?
          </p>
          <a
            href={createWhatsAppUrl("Olá, Mariany! Gostaria de conversar sobre um projeto sob medida para minha empresa e solicitar um orçamento.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all duration-300 shadow-[0_0_25px_rgba(212,175,55,0.25)] hover:shadow-[0_0_35px_rgba(212,175,55,0.45)] active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>Solicitar Orçamento Personalizado no WhatsApp</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>

      {/* Modal */}
      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
      />
    </section>
  );
};
