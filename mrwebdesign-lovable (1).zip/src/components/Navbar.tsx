import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Menu, X, Instagram } from 'lucide-react';
import { createWhatsAppUrl, INSTAGRAM_URL } from '../data/portfolioData';
import mrLogo from '../assets/images/mr_logo_premium_1791784347148.jpg';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Início', href: '#inicio' },
    { label: 'Sobre', href: '#sobre' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Planos', href: '#precos' },
    { label: 'Portfólio', href: '#portfolio' },
    { label: 'Depoimentos', href: '#depoimentos' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#0A0A0A]/90 backdrop-blur-md border-b border-white/[0.08] py-3.5 shadow-2xl'
          : 'bg-transparent py-5 border-b border-white/[0.04]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark (Single clean element) */}
          <a
            href="#inicio"
            className="flex items-center gap-2.5 group whitespace-nowrap shrink-0 text-decoration-none"
            aria-label="MR Web Design - Início"
          >
            <span className="w-9 h-9 rounded-lg overflow-hidden border border-[#D4AF37]/50 flex items-center justify-center bg-black transition-all duration-300 group-hover:border-[#D4AF37] group-hover:shadow-[0_0_15px_rgba(212,175,55,0.4)] shrink-0">
              <img
                src={mrLogo}
                alt="MR Web Design Logo Oficial"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </span>
            <span className="font-serif-luxury text-base sm:text-lg font-bold tracking-tight text-white group-hover:text-[#D4AF37] transition-colors">
              MR Web Design
            </span>
          </a>

          {/* Zone 2: 4-5 single-line nav links + Instagram */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-neutral-300">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="whitespace-nowrap shrink-0 hover:text-[#D4AF37] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1.5px] after:bg-[#D4AF37] hover:after:w-full after:transition-all after:duration-300"
              >
                {item.label}
              </a>
            ))}
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-neutral-400 hover:text-[#D4AF37] transition-colors text-xs tracking-wide shrink-0"
              title="Instagram @mrwebdesign.br"
              aria-label="Instagram MR Web Design"
            >
              <Instagram className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="hidden xl:inline">@mrwebdesign.br</span>
            </a>
          </nav>

          {/* Zone 3: 1 Primary CTA Button */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <a
              href={createWhatsAppUrl("Olá, Mariany! Gostaria de solicitar um orçamento exclusivo no WhatsApp.")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all duration-300 hover:shadow-[0_0_20px_rgba(212,175,55,0.35)] active:scale-95 whitespace-nowrap shrink-0"
            >
              <span>Solicitar Orçamento</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Mobile Menu Toggle Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-neutral-300 hover:text-[#D4AF37] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
              aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0D0D0D] border-b border-white/[0.08] px-6 py-6 transition-all animate-fadeIn">
          <nav className="flex flex-col gap-4 text-base font-medium text-neutral-300">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-1 hover:text-[#D4AF37] transition-colors"
              >
                {item.label}
              </a>
            ))}
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 py-2 text-sm text-neutral-400 hover:text-[#D4AF37] transition-colors"
            >
              <Instagram className="w-4 h-4 text-[#D4AF37]" />
              <span>Instagram: @mrwebdesign.br</span>
            </a>
            <div className="pt-2">
              <a
                href={createWhatsAppUrl("Olá, Mariany! Vim pelo menu do site e quero solicitar um orçamento no WhatsApp.")}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 py-3 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all"
              >
                <span>Solicitar Orçamento no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
