import React from 'react';
import { Instagram, MessageSquare, ArrowUpRight } from 'lucide-react';
import { 
  WHATSAPP_DISPLAY, 
  INSTAGRAM_URL, 
  INSTAGRAM_HANDLE, 
  createWhatsAppUrl 
} from '../data/portfolioData';
import mrLogo from '../assets/images/mr_logo_premium_1791784347148.jpg';

interface FooterProps {
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin }) => {
  return (
    <footer className="bg-[#080808] border-t border-white/[0.08] text-neutral-400 py-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 pb-12 border-b border-white/[0.06]">
          
          {/* Brand & Purpose (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <span className="w-9 h-9 rounded-lg overflow-hidden border border-[#D4AF37]/50 flex items-center justify-center bg-black shrink-0">
                <img
                  src={mrLogo}
                  alt="MR Web Design Logo Oficial"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </span>
              <span className="font-serif-luxury text-xl font-bold tracking-tight text-white">
                MR Web Design
              </span>
            </div>

            <p className="text-sm text-neutral-300 max-w-sm leading-relaxed">
              &ldquo;O futuro da sua marca começa aqui.&rdquo; Criação de sites modernos, responsivos e de alto padrão voltados para empresas que desejam acelerar seu faturamento.
            </p>

            <div className="text-xs text-neutral-400">
              Criado e liderado por <strong>Mariany Rodrigues</strong> · Atendimento em todo o Brasil.
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-3">
            <p className="text-xs font-semibold text-white uppercase tracking-wider">
              Navegação
            </p>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#inicio" className="hover:text-[#D4AF37] transition-colors">Início</a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-[#D4AF37] transition-colors">Sobre Nós</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Serviços</a>
              </li>
              <li>
                <a href="#precos" className="hover:text-[#D4AF37] transition-colors">Planos & Preços</a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-[#D4AF37] transition-colors">Portfólio</a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-[#D4AF37] transition-colors">Depoimentos</a>
              </li>
              <li>
                <a href="#contato" className="hover:text-[#D4AF37] transition-colors">Contato & Orçamento</a>
              </li>
            </ul>
          </div>

          {/* Services Quicklist */}
          <div className="space-y-3">
            <p className="text-xs font-semibold text-white uppercase tracking-wider">
              Soluções
            </p>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Landing Pages de Conversão</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Sites Institucionais</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Lojas Virtuais & E-commerce</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Redesign & Performance</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Portfólios de Autoridade</a>
              </li>
            </ul>
          </div>

          {/* Direct Channels */}
          <div className="space-y-3">
            <p className="text-xs font-semibold text-white uppercase tracking-wider">
              Canais Oficiais
            </p>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href={createWhatsAppUrl("Olá, Mariany! Gostaria de falar sobre o projeto de um site pelo WhatsApp.")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-[#D4AF37] transition-colors group"
                >
                  <MessageSquare className="w-4 h-4 text-[#D4AF37]" />
                  <span>{WHATSAPP_DISPLAY}</span>
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                </a>
              </li>
              <li>
                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-[#D4AF37] transition-colors group"
                >
                  <Instagram className="w-4 h-4 text-[#D4AF37]" />
                  <span>@{INSTAGRAM_HANDLE}</span>
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                </a>
              </li>
            </ul>

            <div className="pt-2">
              <span className="text-[11px] text-neutral-400 block">
                Atendimento 100% online para todo o Brasil
              </span>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <div className="flex items-center gap-3">
            <span>&copy; {new Date().getFullYear()} MR Web Design. Todos os direitos reservados.</span>
            {onOpenAdmin && (
              <button
                onClick={onOpenAdmin}
                className="text-neutral-700 hover:text-[#D4AF37] transition-colors text-[10px]"
                title="Configuração de Foto (Criadora)"
              >
                · Painel Mariany
              </button>
            )}
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[#D4AF37] font-mono text-[11px]">mrwebdesign.com</span>
            <span aria-hidden="true">·</span>
            <span>Brasil</span>
            <span aria-hidden="true">·</span>
            <span>Alta Performance & Conversão</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
