import React from 'react';
import { Check, ArrowUpRight, ShieldCheck, Sparkles } from 'lucide-react';
import { PRICING_PLANS, createWhatsAppUrl } from '../data/portfolioData';

export const Pricing: React.FC = () => {
  return (
    <section id="precos" className="py-20 md:py-32 bg-[#0A0A0A] relative border-t border-white/[0.06]">
      {/* Subtle gold glow in background */}
      <div 
        className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[400px] pointer-events-none opacity-20 blur-[130px] rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(212, 175, 55, 0.3) 0%, rgba(10, 10, 10, 0) 70%)'
        }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16 text-center mx-auto">
          <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
            Tabela de Preços & Planos Acessíveis
          </p>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
            Investimento Transparente para o Seu Negócio
          </h2>
          <div className="w-16 h-[2px] bg-[#D4AF37] mx-auto mt-5 mb-4" />
          <p className="text-base text-neutral-300 max-w-2xl mx-auto">
            Qualidade profissional de alto padrão com preços justos e acessíveis. Escolha o plano ideal para a fase atual da sua empresa.
          </p>
        </div>

        {/* 3 Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {PRICING_PLANS.map((plan) => {
            const isFeatured = plan.popular;
            return (
              <div
                key={plan.id}
                className={`rounded-2xl flex flex-col justify-between transition-all duration-300 relative ${
                  isFeatured
                    ? 'bg-gradient-to-b from-[#181818] to-[#121212] border-2 border-[#D4AF37] shadow-[0_0_35px_rgba(212,175,55,0.25)] md:-translate-y-2'
                    : 'bg-[#121212] border border-white/[0.08] hover:border-[#D4AF37]/50 hover:bg-[#161616]'
                } p-7 sm:p-8`}
              >
                {/* Popular Pill badge if featured */}
                {isFeatured && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-[#D4AF37] text-black text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full shadow-md flex items-center gap-1 whitespace-nowrap">
                    <Sparkles className="w-3 h-3" />
                    <span>Mais Escolhido</span>
                  </div>
                )}

                <div>
                  {/* Plan Tier & Title */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono font-bold tracking-wider text-[#D4AF37] border border-[#D4AF37]/30 px-2.5 py-0.5 rounded bg-[#181818]">
                      Plano {plan.tier}
                    </span>
                    <span className="text-xs uppercase tracking-wider text-neutral-400 font-medium">
                      Pagamento Único
                    </span>
                  </div>

                  <h3 className="font-serif-luxury text-2xl font-bold text-white mb-2">
                    {plan.name}
                  </h3>

                  {/* Price */}
                  <div className="my-5 pb-5 border-b border-white/[0.08]">
                    <div className="flex items-baseline gap-1">
                      <span className="font-serif-luxury text-3xl sm:text-4xl font-extrabold text-white">
                        {plan.price}
                      </span>
                    </div>
                    <p className="text-xs text-[#D4AF37] font-medium mt-2 leading-relaxed">
                      {plan.tagline}
                    </p>
                  </div>

                  {/* Features list */}
                  <div className="space-y-3 mb-8">
                    <p className="text-xs uppercase tracking-wider text-neutral-400 font-semibold">
                      O que está incluso:
                    </p>
                    {plan.features.map((feature, fIdx) => (
                      <div key={fIdx} className="flex items-start gap-2.5 text-xs text-neutral-300">
                        <Check className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                        <span className="leading-snug">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card Action */}
                <div className="pt-6 border-t border-white/[0.06] space-y-4">
                  <div className="text-[11px] text-neutral-400 text-center">
                    <span className="text-neutral-500">Ideal para:</span> {plan.idealFor}
                  </div>

                  <a
                    href={createWhatsAppUrl(`Olá, Mariany! Gostaria de contratar o plano ${plan.name} (${plan.price}) para o meu site.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-full py-3.5 px-4 rounded-lg text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all duration-300 ${
                      isFeatured
                        ? 'bg-[#D4AF37] hover:bg-[#E5C365] text-black shadow-[0_0_20px_rgba(212,175,55,0.35)] active:scale-95'
                        : 'bg-[#1C1C1C] hover:bg-[#D4AF37] text-white hover:text-black border border-white/[0.08] hover:border-transparent'
                    }`}
                  >
                    <span>Contratar no WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Security & Guarantee Note */}
        <div className="mt-12 text-center flex flex-wrap items-center justify-center gap-6 text-xs text-neutral-400">
          <span className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
            Sem mensalidades ocultas ou taxas surpresa
          </span>
          <span className="hidden sm:inline text-neutral-600">·</span>
          <span>Parcelamento facilitado disponível</span>
          <span className="hidden sm:inline text-neutral-600">·</span>
          <span>Entrega no prazo com suporte dedicado</span>
        </div>

      </div>
    </section>
  );
};
