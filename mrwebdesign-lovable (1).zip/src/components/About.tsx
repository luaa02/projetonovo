import React, { useState, useEffect } from 'react';
import { Heart, Laptop, Award, CheckCircle2, ArrowUpRight } from 'lucide-react';
import { FOUNDER_INFO, createWhatsAppUrl } from '../data/portfolioData';

interface AboutProps {
  onOpenAdmin?: () => void;
  customPhoto?: string;
}

export const About: React.FC<AboutProps> = ({ onOpenAdmin, customPhoto }) => {
  const [photoSrc, setPhotoSrc] = useState<string>(() => {
    return customPhoto || FOUNDER_INFO.image;
  });

  useEffect(() => {
    if (customPhoto) {
      setPhotoSrc(customPhoto);
    } else {
      setPhotoSrc(FOUNDER_INFO.image);
    }
  }, [customPhoto]);

  return (
    <section id="sobre" className="py-20 md:py-32 bg-[#0E0E0E] relative border-t border-white/[0.06]">
      {/* Glow highlight */}
      <div 
        className="absolute bottom-10 right-0 w-[500px] h-[400px] pointer-events-none opacity-15 blur-[130px] rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(212, 175, 55, 0.4) 0%, rgba(14, 14, 14, 0) 70%)'
        }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="max-w-3xl mb-16">
          <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
            Conheça Quem Está Por Trás dos Projetos
          </p>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
            Sobre a MR Web Design & Mariany Rodrigues
          </h2>
          <div className="w-16 h-[2px] bg-[#D4AF37] mt-5 mb-6" />
          <p className="text-base text-neutral-400">
            Design de alto padrão aliado à estratégia comercial para posicionar sua empresa entre as melhores do seu setor.
          </p>
        </div>

        {/* 2-Column Split: Image on Left/Right, Narrative on other side */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Portrait Column */}
          <div className="lg:col-span-5">
            <div className="relative">
              {/* Gold frame accent */}
              <div 
                className="absolute -inset-2 rounded-2xl bg-gradient-to-tr from-[#D4AF37]/30 to-transparent opacity-60 blur-sm pointer-events-none"
                aria-hidden="true" 
              />
              
              <div className="relative rounded-2xl overflow-hidden border border-white/[0.12] bg-[#141414] shadow-2xl">
                {/* Photo container */}
                <div className="relative">
                  <img
                    src={photoSrc}
                    alt="Mariany Rodrigues, fundadora e designer da MR Web Design"
                    className="w-full h-auto aspect-[4/3] sm:aspect-[4/5] object-cover object-center"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  
                  {/* Subtle glass vignette */}
                  <div 
                    className="absolute inset-0 bg-gradient-to-t from-[#121212]/80 via-transparent to-transparent pointer-events-none" 
                    aria-hidden="true" 
                  />
                </div>

                {/* Subtitle badge in photo card */}
                <div className="p-6 bg-[#121212] border-t border-white/[0.08]">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-serif-luxury text-lg font-bold text-white">
                        Mariany Rodrigues
                      </h3>
                      <p className="text-xs text-[#D4AF37] font-medium tracking-wide">
                        Criadora & Especialista em Web Design
                      </p>
                    </div>
                    <span className="text-xs text-neutral-400 font-mono">
                      Brasil
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Narrative Column */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 text-sm font-semibold text-[#D4AF37]">
                <span>Olá! Sou Mariany Rodrigues, criadora da MR Web Design.</span>
                <Heart className="w-4 h-4 text-[#D4AF37] fill-[#D4AF37]" />
              </div>

              <p className="text-base sm:text-lg text-neutral-200 leading-relaxed">
                Sou apaixonada por tecnologia, criatividade e design. Meu objetivo é transformar ideias em 
                sites modernos, profissionais e personalizados, ajudando marcas e negócios a conquistarem 
                seu espaço com destaque no mundo digital.
              </p>

              <div className="p-5 rounded-xl bg-[#141414] border border-white/[0.08] relative">
                <div className="flex items-start gap-3">
                  <Laptop className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                  <p className="text-sm sm:text-base text-neutral-300 leading-relaxed italic">
                    &ldquo;Acredito que cada projeto é único e merece uma identidade que transmita 
                    profissionalismo, confiança e qualidade. Mais do que criar sites, meu propósito é 
                    transformar ideias em experiência.&rdquo;
                  </p>
                </div>
              </div>
            </div>

            {/* Differential Statement */}
            <div className="pt-2">
              <h4 className="text-xs uppercase tracking-wider text-neutral-400 font-semibold mb-3">
                Nosso Diferencial Competitivo
              </h4>
              <p className="text-sm sm:text-base text-neutral-300 leading-relaxed mb-6">
                Oferecemos sites modernos, responsivos e personalizados, com qualidade e preços acessíveis.
                Nosso diferencial é unir criatividade, tecnologia e atendimento exclusivo para cada cliente.
              </p>

              {/* Pillars Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-[#141414] border border-white/[0.06]">
                  <CheckCircle2 className="w-5 h-5 text-[#D4AF37] mb-2" />
                  <p className="text-xs font-bold text-white mb-1">Criatividade Autêntica</p>
                  <p className="text-xs text-neutral-400">Identidade visual única, sem modelos batidos ou genéricos.</p>
                </div>

                <div className="p-4 rounded-lg bg-[#141414] border border-white/[0.06]">
                  <Award className="w-5 h-5 text-[#D4AF37] mb-2" />
                  <p className="text-xs font-bold text-white mb-1">Tecnologia & Velocidade</p>
                  <p className="text-xs text-neutral-400">Código limpo, seguro e otimizado para os algoritmos do Google.</p>
                </div>

                <div className="p-4 rounded-lg bg-[#141414] border border-white/[0.06]">
                  <Heart className="w-5 h-5 text-[#D4AF37] mb-2" />
                  <p className="text-xs font-bold text-white mb-1">Atendimento Exclusivo</p>
                  <p className="text-xs text-neutral-400">Comunicação próxima, suporte humanizado e respeito ao seu prazo.</p>
                </div>
              </div>
            </div>

            {/* CTA */}
            <div className="pt-4">
              <a
                href={createWhatsAppUrl("Olá, Mariany! Li sobre a sua história na MR Web Design e gostaria de conversar sobre um projeto para minha empresa.")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all duration-300 hover:shadow-[0_0_20px_rgba(212,175,55,0.3)] active:scale-95"
              >
                <span>Falar Diretamente com Mariany</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
