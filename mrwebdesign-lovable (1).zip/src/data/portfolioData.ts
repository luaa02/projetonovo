import { ServiceItem, PortfolioProject, Testimonial, PricingPlan } from '../types';
import marianyOfficialPhoto from '../assets/images/regenerated_image_1791783552129.png';

export const WHATSAPP_RAW = "45998491087";
export const WHATSAPP_DISPLAY = "(45) 99849-1087";
export const INSTAGRAM_HANDLE = "mrwebdesign.br";
export const INSTAGRAM_URL = "https://instagram.com/mrwebdesign.br";
export const SITE_DOMAIN = "mrwebdesign.com";
export const SITE_URL = "https://mrwebdesign.com";

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: "site-simples",
    tier: "01",
    name: "Site Simples",
    price: "R$ 300,00",
    tagline: "Perfeito para começar sua presença online com profissionalismo.",
    features: [
      "Landing Page moderna e 100% responsiva",
      "Apresentação limpa dos seus serviços e marca",
      "Botão de contato direto integrado ao WhatsApp",
      "Otimização para carregamento rápido em celulares",
      "Entrega ágil com atendimento exclusivo"
    ],
    idealFor: "Profissionais autônomos e pequenos negócios no início"
  },
  {
    id: "site-essencial",
    tier: "02",
    name: "Site Essencial",
    price: "R$ 600,00",
    tagline: "Mais páginas, funcionalidades e possibilidades para sua marca.",
    popular: true,
    features: [
      "Estrutura multi-páginas (Início, Sobre, Serviços, Contato)",
      "Design personalizado alinhado à sua identidade visual",
      "Copywriting persuasivo focado em converter clientes",
      "Integração com WhatsApp, Redes Sociais e Mapa",
      "Formulário de captura de orçamentos e leads",
      "Configuração básica de SEO para buscas no Google"
    ],
    idealFor: "Empresas em crescimento que precisam de autoridade"
  },
  {
    id: "site-premium",
    tier: "03",
    name: "Site Premium",
    price: "R$ 1.000,00",
    tagline: "Uma experiência digital completa, personalizada e sofisticada",
    features: [
      "Design de alto padrão sob medida (Luxo / Dark / Editorial)",
      "Catálogo completo, e-commerce ou sistema sob demanda",
      "Performance máxima (PageSpeed 90+) e ultra velocidade",
      "Integração com Pixel do Facebook/Instagram e Google Ads",
      "SEO avançado para posicionamento de destaque",
      "Suporte prioritário VIP e treinamento para atualizações"
    ],
    idealFor: "Marcas consolidadas que buscam faturamento em escala"
  }
];

export const createWhatsAppUrl = (customMessage?: string) => {
  const defaultMsg = "Olá, Mariany! Gostaria de solicitar um orçamento para criação de site com a MR Web Design e acelerar as vendas da minha empresa.";
  const text = encodeURIComponent(customMessage || defaultMsg);
  return `https://wa.me/55${WHATSAPP_RAW}?text=${text}`;
};

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "landing-pages",
    number: "01",
    title: "Landing Pages de Alta Conversão",
    shortDesc: "Páginas com arquitetura persuasiva, carregamento ultra veloz e design magnético voltadas para converter cliques em contatos diretos no WhatsApp.",
    features: [
      "Copywriting estruturado para conversão",
      "Otimização extrema de velocidade (PageSpeed 90+)",
      "Integração nativa com WhatsApp e Pixel de Anúncios",
      "Responsividade impecável para telas mobile"
    ],
    idealFor: "Campanhas de tráfego pago, lançamentos de produtos e serviços locais",
    impactMetric: "+120% a +250% em conversão de leads"
  },
  {
    id: "sites-institucionais",
    number: "02",
    title: "Sites Institucionais & Corporativos",
    shortDesc: "Posicionamento digital de autoridade máxima. Transmita o valor, solidez e credibilidade que a sua marca precisa para fechar contratos de alto tíquete.",
    features: [
      "Apresentação executiva da marca e serviços",
      "Estrutura multi-páginas pensada na experiência do usuário",
      "Otimização SEO para buscas no Google",
      "Painel administrativo intuitivo para atualizações"
    ],
    idealFor: "Empresas consolidadas, clínicas, escritórios e indústrias",
    impactMetric: "Autoridade inquestionável para negociações"
  },
  {
    id: "lojas-virtuais",
    number: "03",
    title: "Lojas Virtuais & E-commerce",
    shortDesc: "Plataformas de vendas robustas, atraentes e simplificadas, desenvolvidas para transformar navegadores casuais em compradores fiéis.",
    features: [
      "Design de catálogo sofisticado e minimalista",
      "Checkout transparente e seguro",
      "Integração de frete, cartões e PIX instantâneo",
      "Recuperação de carrinhos e gestão de estoque"
    ],
    idealFor: "Marcas de vestuário, cosméticos, joias e produtos físicos",
    impactMetric: "Experiência de compra fluida sem fricção"
  },
  {
    id: "redesign-otimizacao",
    number: "04",
    title: "Redesign & Otimização de Performance",
    shortDesc: "Transformamos sites ultrapassados, lentos ou confusos em experiências digitais contemporâneas, elegantes e com foco em faturamento.",
    features: [
      "Diagnóstico completo de usabilidade e gargalos de vendas",
      "Reformulação visual completa alinhada à nova fase da empresa",
      "Aceleração de código e eliminação de lentidão",
      "Adequação técnica aos padrões modernos de SEO"
    ],
    idealFor: "Negócios com sites desatualizados perdendo espaço no mercado",
    impactMetric: "Redução de até 70% na taxa de rejeição"
  },
  {
    id: "portfolios-exclusivos",
    number: "05",
    title: "Portfólios & Páginas de Autoridade",
    shortDesc: "Projetos personalizados para profissionais liberais e consultores que precisam demonstrar excelência técnica e valorizar seus honorários.",
    features: [
      "Curadoria visual de projetos e trabalhos anteriores",
      "Destaque estratégico para depoimentos e certificações",
      "Chamadas para ação direcionadas para agenda e consultoria",
      "Identidade visual memorável e autêntica"
    ],
    idealFor: "Médicos, arquitetos, advogados, consultores e executivos",
    impactMetric: "Valorização comprovada da percepção de marca"
  }
];

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: "aurelia-luxe",
    title: "Aurélia Lune — Alta Joalheria & Boutique",
    category: "E-commerce Premium",
    client: "Aurélia Lune Paris & São Paulo",
    year: "2026",
    impact: "+185% de conversão no checkout mobile",
    description: "Desenvolvimento de e-commerce com estética dark luxury e detalhes em dourado refinado. Catálogo interativo com zoom de alta resolução, fluxo de compra em 3 passos e integração direta de atendimento consultivo via WhatsApp para peças exclusivas.",
    deliverables: [
      "Arquitetura de informação e UX/UI sob medida",
      "Checkout integrado com PIX e parcelamento transparente",
      "Atendimento VIP via botão WhatsApp conectado a cada produto",
      "Carregamento em menos de 1,2 segundos"
    ],
    imageUrl: "/images/portfolio_luxury.jpg",
    aspectRatio: "4:3",
    accentText: "Luxo & Alta Conversão"
  },
  {
    id: "aesthetic-clinic",
    title: "The Aesthetic Clinic — Dermatologia & Estética Avançada",
    category: "Saúde & Estética de Luxo",
    client: "The Aesthetic Clinic",
    year: "2026",
    impact: "+240% em agendamentos de consultas particulares",
    description: "Criação de site institucional de alto padrão para clínica médica renomada. Estrutura voltada a transmitir serenidade, segurança médica e sofisticação, com botões estratégicos que direcionam os pacientes diretamente para a triagem da secretária no WhatsApp.",
    deliverables: [
      "Design de autoridade médica com paleta premium",
      "Apresentação visual de procedimentos e tratamentos",
      "Página otimizada para SEO local em pesquisas do Google",
      "Fluxo de agendamento ágil sem burocracia"
    ],
    imageUrl: "/images/portfolio_clinic.jpg",
    aspectRatio: "4:3",
    accentText: "Autoridade Médica"
  },
  {
    id: "elevate-architecture",
    title: "Elevate & Orion Tech — Consultoria e Arquitetura Corporativa",
    category: "Site Institucional B2B",
    client: "Grupo Elevate Solutions",
    year: "2026",
    impact: "+310% de solicitações de propostas comerciais",
    description: "Plataforma digital para escritório de arquitetura e tecnologia corporativa. Linhas minimalistas, contraste refinado e narrativa visual que destaca o portfólio de empreendimentos industriais e sedes de empresas multinacionais.",
    deliverables: [
      "Galeria imersiva de projetos concluídos",
      "Apresentação técnica de credenciais e cases de sucesso",
      "Formulário executivo conectado com notificação WhatsApp",
      "Compatibilidade completa com monitores 4K e smartphones"
    ],
    imageUrl: "/images/hero_showcase.jpg",
    aspectRatio: "16:9",
    accentText: "Corporativo B2B"
  }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: "depoimento-1",
    name: "Dra. Vanessa Martins",
    role: "Diretora Médica & Proprietária",
    company: "Clínica Splendor Estética",
    quote: "Antes o nosso site parecia genérico e não passava o valor dos nossos procedimentos de alto padrão. A Mariany redesenhou tudo com uma elegância ímpar. No primeiro mês após a entrega, os agendamentos particulares triplicaram pelo WhatsApp.",
    metric: "3x mais agendamentos particulares"
  },
  {
    id: "depoimento-2",
    name: "Lucas Alencar",
    role: "Sócio Administrador",
    company: "Alencar & Prado Advocacia Empresarial",
    quote: "A MR Web Design entendeu com perfeição a sobriedade que um escritório jurídico exige sem deixar a página pesada. O site transmite solidez imediata aos nossos clientes corporativos. O retorno financeiro cobriu o investimento logo na primeira semana.",
    metric: "ROI obtido na 1ª semana"
  },
  {
    id: "depoimento-3",
    name: "Camila Siqueira",
    role: "Fundadora & Designer de Joias",
    company: "Siqueira Joias Contemporâneas",
    quote: "Nossa loja virtual precisava de uma atmosfera exclusiva de luxo. A Mariany é extremamente atenciosa, rápida e apaixonada pelo que faz. A experiência dos clientes foi da água para o vinho, com aumento direto nas nossas vendas diárias.",
    metric: "+180% de vendas no e-commerce"
  },
  {
    id: "depoimento-4",
    name: "Rodrigo Becker",
    role: "Diretor Comercial",
    company: "Becker Engenharia & Soluções",
    quote: "Precisávamos de um site que convertesse visitantes corporativos em reuniões com nossa equipe. A estrutura desenvolvida pela MR Web Design é objetiva, limpa e altamente persuasiva. Recomendo de olhos fechados a qualquer empresário sério.",
    metric: "+42 novos contratos qualificados"
  }
];

export const FOUNDER_INFO = {
  name: "Mariany Rodrigues",
  role: "Criadora da MR Web Design",
  tagline: "O futuro da sua marca começa aqui.",
  intro: "Olá! Sou Mariany Rodrigues, criadora da MR Web Design. ❤️",
  story: "Sou apaixonada por tecnologia, criatividade e design. Meu objetivo é transformar ideias em sites modernos, profissionais e personalizados, ajudando marcas e negócios a conquistarem seu espaço no mundo digital.",
  belief: "💻 Acredito que cada projeto é único e merece uma identidade que transmita profissionalismo, confiança e qualidade.",
  purpose: "Mais do que criar sites, meu propósito é transformar ideias em experiência.",
  differential: "Oferecemos sites modernos, responsivos e personalizados, com qualidade e preços acessíveis. Nosso diferencial é unir criatividade, tecnologia e atendimento exclusivo para cada cliente.",
  image: marianyOfficialPhoto
};
