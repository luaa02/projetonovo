import React, { useEffect } from 'react';
import { X, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { PortfolioProject } from '../types';
import { createWhatsAppUrl } from '../data/portfolioData';

interface ProjectModalProps {
  project: PortfolioProject | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 bg-black/85 backdrop-blur-md overflow-y-auto"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-project-title"
    >
      <div 
        className="relative w-full max-w-4xl bg-[#121212] border border-white/[0.12] rounded-2xl shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-white/[0.08] bg-[#161616]">
          <div>
            <span className="text-xs uppercase tracking-wider text-[#D4AF37] font-semibold">
              {project.category} · {project.year}
            </span>
            <h3 id="modal-project-title" className="font-serif-luxury text-xl sm:text-2xl font-bold text-white">
              {project.title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-[#202020] hover:bg-[#2A2A2A] text-neutral-300 hover:text-white transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
            aria-label="Fechar modal de detalhes do projeto"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Main Visual */}
          <div className="relative rounded-xl overflow-hidden border border-white/[0.08] bg-black">
            <img
              src={project.imageUrl}
              alt={project.title}
              className="w-full h-auto object-cover max-h-[420px]"
              referrerPolicy="no-referrer"
            />
            {/* Impact overlay badge */}
            <div className="absolute bottom-4 left-4 right-4 sm:right-auto bg-[#0A0A0A]/90 backdrop-blur-md border border-[#D4AF37]/40 px-4 py-2.5 rounded-lg shadow-lg">
              <span className="text-xs text-neutral-400 block font-sans">Resultado Alcançado:</span>
              <span className="text-sm font-semibold text-[#D4AF37] font-sans">{project.impact}</span>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-4">
            <h4 className="text-sm uppercase tracking-wider text-neutral-400 font-semibold">
              Sobre o Projeto & Estratégia
            </h4>
            <p className="text-base text-neutral-200 leading-relaxed">
              {project.description}
            </p>
          </div>

          {/* Deliverables Checklist */}
          <div className="space-y-3 pt-2">
            <h4 className="text-sm uppercase tracking-wider text-neutral-400 font-semibold">
              Entregáveis & Diferenciais Implementados
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {project.deliverables.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2.5 p-3 rounded-lg bg-[#181818] border border-white/[0.06] text-xs text-neutral-300">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom Action Strip */}
          <div className="pt-6 border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-neutral-400 text-center sm:text-left">
              Interessado em um projeto com esse nível de acabamento e resultado?
            </div>
            <a
              href={createWhatsAppUrl(`Olá, Mariany! Gostei muito do projeto ${project.title} e gostaria de solicitar um orçamento para um site similar para a minha empresa.`)}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] active:scale-95"
            >
              <span>Quero um Site Similar no WhatsApp</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
